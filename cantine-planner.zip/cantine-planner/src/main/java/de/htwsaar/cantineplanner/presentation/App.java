package de.htwsaar.cantineplanner.presentation;

import com.googlecode.lanterna.gui2.MultiWindowTextGUI;
import com.googlecode.lanterna.gui2.WindowBasedTextGUI;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;
import de.htwsaar.cantineplanner.tuiPresentationNew.LoginScreen;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App {
    public static void main(String[] args) {

        setupDatabase(); // set up the database to be able to use it

        try {
            Terminal terminal = new DefaultTerminalFactory().createTerminal();
            Screen screen = new TerminalScreen(terminal);
            screen.startScreen();

            WindowBasedTextGUI textGUI = new MultiWindowTextGUI(screen);

            LoginScreen loginScreen = new LoginScreen((MultiWindowTextGUI) textGUI);
            loginScreen.display();

            screen.stopScreen();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setupDatabase() {
        Path dbPath = Paths.get("database/database.db");  //target for the DB

        // case DB not found : need to create it
        if (!Files.exists(dbPath)) {
            System.out.println(" Database not found ! need to create one! ");

            try {
                // creates folder  "database/", if not already exists.
                Files.createDirectories(dbPath.getParent());

                // copies database.db from the FAT Jar into the folder
                // needed, as resource directory inside project is set to be read-only
                copyDatabaseFromJar("database.db", dbPath.toString());
                System.out.println(" Database successfully created at : " + dbPath);
            } catch (IOException e) {
                System.err.println(" Error encountered whilst copying the database  " + e.getMessage());
            }
        } else {
            System.out.println(" Database already exists at :  " + dbPath.toAbsolutePath());
        }
    }


    // Copying of the needed database from inside the FAT Jar File
    private static void copyDatabaseFromJar(String resourceName, String outputPath) throws IOException {

        try (InputStream inputStream = App.class.getClassLoader().getResourceAsStream(resourceName);
             FileOutputStream outputStream = new FileOutputStream(outputPath)) {

            if (inputStream == null) {
                throw new IOException("Datenbank nicht gefunden! : " + resourceName);
            }

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }


    }

}